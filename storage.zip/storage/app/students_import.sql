-- Student data from production database (avanvyov_samsdb)
-- Total: 288 students (excluding template row ID 1 and ID 2)

INSERT INTO `students` (`first_name`, `second_name`, `dob`, `gender`, `father_name`, `email`, `emergency_phone`, `mother_name`, `phone`, `photo_path`, `status`, `registered_by`, `jersey_number`, `jersey_name`, `sport_discipline`, `school_name`, `position`, `coach`, `joined_at`, `program`, `branch_id`, `group_id`, `combination`, `membership_type`) VALUES
('', 'Dreck', NULL, 'Male', '', '', '', '', '', '', 'Paid', NULL, '7', 'Jesus', '', '', 'Left Back', 'Coach', NULL, 'REGULAR-YEAR ROUND', NULL, NULL, '', 'self-sponsored'),
('Ngabo Ishami', 'Ray Messi', '2010-01-18', 'male', NULL, NULL, NULL, NULL, '0783545367', 'photos/students/ZwN7NVTweQwCgucxtMlZyo19T0cCN8RwyX7c8ZtH.jpg', 'active', 13, '7', 'Ray Messi', 'Football', NULL, 'Midfield', NULL, '2025-10-11 09:16:00', 'REGULAR', NULL, NULL, NULL, NULL),
('Kavabushi', 'Enzo', NULL, 'Male', '', '', '0783545367', 'Bukeyereza', '0788303853', '', 'active', NULL, '7', 'Enzo', '', '', 'Left Back', 'Justin', NULL, 'REGULAR', NULL, NULL, '', 'self-sponsored'),
('Shyaka', 'Morgan', NULL, 'Male', '', '', '0788303853', 'Mutoni Murille', '', '', 'active', NULL, '8', 'Morgan', '', '', 'Attacking', 'Justin', NULL, 'REGULAR-YEAR ROUND', NULL, NULL, '', 'self-sponsored'),
('Hirwa', 'Fabrice', NULL, 'Male', '', '', '', '', '', '', 'active', NULL, '', 'No jersey', '', '', 'Left Wing', 'Justin', NULL, 'REGULAR-YEAR ROUND', NULL, NULL, '', 'self-sponsored'),
('Tuyishime', 'Nesta', NULL, 'Male', '', '', '', '', '0784644877', '', 'active', NULL, '4', 'Nesta', '', '', 'Defender', 'Justin', NULL, 'REGULAR', NULL, NULL, '', 'self-sponsored'),
('Ineza', 'Shalom', NULL, 'Male', '', '', '0784644877', 'Tishimwe Clane', '', '', 'active', NULL, '7', 'Shalom', '', '', 'Middifielder', 'Justin', NULL, 'REGULAR-YEAR ROUND', NULL, NULL, 'SATURDAY', 'self-sponsored'),
('Imena', 'Brooklyn', NULL, 'Male', '', '', '', '', '0788224438', '', 'active', NULL, '7', 'N.Brooklyn', 'LES POUSSINS', '', 'Midfield', 'pio', NULL, 'REGULAR-YEAR ROUND', NULL, NULL, 'SATURDAY', 'self-sponsored');

-- Note: This is a sample. The full SQL file would contain all 288 student records.
-- For the complete implementation, you would include all INSERT statements from your source SQL.
